APP_NAME = "bookinfo"
#APP_NAME = "onlineboutique"

SERVER_IP = "193.225.251.227"
SERVER_PORT = "30861"
SERVER_BASE_URL = f"http://{SERVER_IP}:{SERVER_PORT}"

NAMESPACE = "default"

APP_CONFIGS = {
    "bookinfo": {
        "app_port": "30830",
        "locust_file": "load/book-info/wiki_locustfile.py",
        "root_service": "productpage-v1",
        "deployment_names": [
            "productpage-v1",
            "details-v1",
            "ratings-v1",
            "reviews-v1",
            "reviews-v2",
            "reviews-v3",
        ],
    },
    "onlineboutique": {
        "app_port": "30830",
        "locust_file": "load/online-boutique/wiki_locustfile.py",
        "root_service": "frontend",
        "deployment_names": [
            "frontend",
            "cartservice",
            "checkoutservice",
            "currencyservice",
            "emailservice",
            "paymentservice",
            "productcatalogservice",
            "recommendationservice",
            "shippingservice",
            "adservice",
        ],
    },
}

for app_cfg in APP_CONFIGS.values():
    app_cfg["host"] = f"http://{SERVER_IP}:{app_cfg['app_port']}"

APP = APP_CONFIGS[APP_NAME]
APP_PORT = APP["app_port"]
APP_HOST = APP["host"]

ONLINE_BOUTIQUE_HOST = APP_CONFIGS["onlineboutique"]["host"]
BOOKINFO_HOST = APP_CONFIGS["bookinfo"]["host"]

WORKLOAD_NAME = ["wiki_load"]
#WORKLOAD_NAME = ["constant-20"]

#WORKLOAD_NAME = ["linear-up-down-300"]
#WORKLOAD_NAME = ["linear-200"]
#WORKLOAD_NAME = ["linear-100", "linear-200", "linear-300", "linear-400", "linear-500"]
#WORKLOAD_NAME = ["low-high-100", "low-high-200", "low-high-300", "low-high-400", "low-high-500"]
#WORKLOAD_NAME = ["linear-200"]
#WORKLOAD_NAME = ["stepped-500-up"]
#, "wiki_load"]


LOCUST_FILES = {
    app_name: app_cfg["locust_file"]
    for app_name, app_cfg in APP_CONFIGS.items()
}

AUTOSCALER_SETTINGS = [
# {
#        "autoscaler_name": "pbscaler",
#        "deployment_names": APP["deployment_names"],
#        "config": {
#            "image": "proactivellmbasedproject/pbscaler-boutique:latest",
#            "prom_url": "http://prometheus.istio-system.svc.cluster.local:9090",
#            "kubeconfig_secret": "pbscaler-kubeconfig",
#
#            # PBScaler settings
#            "slo_ms": 500,
#            "duration_seconds": 1200,
#            "num_services": len(APP["deployment_names"]),
#
#            # Scaling bounds
#            "min_replicas": 1,
#            "max_replicas": 10,
#
#            # App metadata
#            "app_name": APP_NAME,
#            "root_service": APP["root_service"],
#        },
#    },
#
#{
#    "autoscaler_name": "hab",
#    "deployment_names": APP["deployment_names"],
#    "config": {
#        "image": "zewang42/hab-autoscaler",
#        "prom_url": "http://prometheus.istio-system.svc.cluster.local:9090/api/v1/query",
#        "interval": 15,
#
#        "app_name": APP_NAME,
#        "root_service": APP["root_service"],
#
#        # HAB calibrated inputs for Online Boutique
#        "lambda_base_rps": 139.11,
#        "phi_base": 3.37,
#
#        # HAB Algorithm 2 latency band
#        "r_up_ms": 500,
#        "r_low_ms": 300,
#
#        # Wait after proportional scaling before exploratory scaling
#        "hab_post_proportional_wait_seconds": 60,
#        "hab_stabilization_seconds": 60,
#
#        # Scaling bounds
#        "min_replicas": 1,
#        "max_replicas": 10,
#
#        # Algorithm 2 exploratory settings
#        "hab_exploratory_enabled": True,
#        "hab_exploratory_max_steps": 3,
#        "hab_stable_lambda_rel_delta": 0.10,
#        "hab_scale_down_enabled": True,
#    },
#},

{
    "autoscaler_name": "customdas",
    "deployment_names": APP["deployment_names"],
    "config": {
        "image": "zewang42/customdas-autoscaler-cpu-queue:latest",
        "prom_url": "http://prometheus.istio-system.svc.cluster.local:9090/api/v1/query",
        "interval": 15,

        "app_name": APP_NAME,
        "root_service": APP["root_service"],

        "p2p_hub_deployment": APP["root_service"],
        "p2p_hub_port": 5000,

        # SLO configuration
        "slo_ms": 500,
        "slo_leaf_ms": 20,

        # Percentile settings
        "slo_latency_percentile": "p95",
        "queue_model_percentile": "p90",


    },
},
#    {
#        "autoscaler_name": "customdas",
#        "deployment_names": APP["deployment_names"],
#        "config": {
#            "image": "zewang42/customdas-autoscaler:latest",
#            "prom_url": "http://prometheus.istio-system.svc.cluster.local:9090/api/v1/query",
#            "interval": 15,
#
#            # App-aware DAS settings passed through server templates into pod env vars.
#            "app_name": APP_NAME,
#            "root_service": APP["root_service"],
#
#            # P2P hub should be the root/frontend deployment of the selected app.
#            "p2p_hub_deployment": APP["root_service"],
#            "p2p_hub_port": 5000,
#
#            # Scaling parameters.
#            "alpha_down_threshold": 30,
#            "tau_min": 60,
#            "tau_max": 80,
#            "beta_up_threshold": 95,
#            "min_replicas": 1,
#            "max_replicas": 10,
#        },
#    },
#    {
#        "autoscaler_name": "das",
#        "deployment_names": APP["deployment_names"],
#        "config": {
#            "image": "zewang42/das-autoscaler:latest",
#            "prom_url": "http://prometheus.istio-system.svc.cluster.local:9090/api/v1/query",
#            "interval": 30,
#            "cooldown_seconds": 30,
#            "alpha_down_threshold": 30,
#            "tau_min": 60,
#            "tau_max": 80,
#            "beta_up_threshold": 95,
#            "min_replicas": 1,
#            "max_replicas": 10,
#        },
#    },
#    {
#        "autoscaler_name": "default_cpu",
#        "deployment_names": APP["deployment_names"],
#        "config": {
#            "average_cpu_utilization": 80,
#            "min_replicas": 1,
#            "max_replicas": 10,
#        },
#    },
]

DURATION_SECONDS = 60 * 72
MONITOR_INTERVAL = 5
PROM_URL = "http://prometheus.istio-system.svc.cluster.local:9090/api/v1/query"

TMP_DIR = "tmp"
WAIT_BETWEEN_EXPERIMENTS_SECONDS = 20
